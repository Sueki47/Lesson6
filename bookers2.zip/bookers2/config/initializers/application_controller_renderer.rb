# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '148d3df7c8296bb5b972ceb5d0269d2ccd41260fdbe3c1e53f0bc4aee44016a067139f34be1ee5cc165f4f9107e4e7798d5a37309e0382884ff47456a633cb1b'

