class BooksController < ApplicationController
   before_action :specified_user, only: [:edit] 
  
  def create
    @book = Book.new(book_params)
    @book.user_id = current_user.id
    if @book.save
      flash[:notice] = 'You have created book successfully.'
      redirect_to book_path(@book.id)
    else
      @user = User.find(current_user.id)
      @books = Book.all
      render :index
    end
  end

  def index
    @book = Book.new
    @user = User.find(current_user.id)
    @books = Book.all
  end

  def show
    @book = Book.new
    @bshow = Book.find(params[:id])
    @user = @bshow.user
    
    
  end

  def destroy
    @bshow = Book.find(params[:id])
    @bshow.destroy
    redirect_to books_path
  end
  
  def edit
  end
  
  def update
    @bshow = Book.find(params[:id])
    if @bshow.update(book_params)
      flash[:notice] = 'You have updated book successfully.'
      redirect_to book_path(@bshow.id)
    else
      render :edit
    end
  end
  private
  
  def specified_user
    @bshow = Book.find(params[:id])
    unless @bshow.user.id == current_user.id 
      redirect_to books_path
    end
  end
  
  def book_params
    params.require(:book).permit(:title, :body, :user_id)
  end
end
